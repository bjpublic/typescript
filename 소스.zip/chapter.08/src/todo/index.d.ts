interface ITodo {
  id: string;
  task: string;
  isCompleted: boolean;
  deletedAt: number;
  createdAt: string;
}