module.exports = {
  runtimeCompiler: true
}