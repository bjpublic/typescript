import { Category } from './Category';
import { User } from './User';

const entities = [
  User,
  Category,
];

export default entities;
