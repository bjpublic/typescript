export default {
  jwtSecret: '3igjkb8i5jhk35r6yyh'
};
