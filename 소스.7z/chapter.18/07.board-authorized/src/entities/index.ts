import { User } from './User';

const entities = [
  User,
];

export default entities;
