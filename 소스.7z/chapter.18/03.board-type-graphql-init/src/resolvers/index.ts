import { HelloResolver } from './common/HelloResolver';

const resolvers = [
  HelloResolver,
];

export default resolvers;
